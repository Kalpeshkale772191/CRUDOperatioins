import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/models/employees.model';
import { EmployeesService } from 'src/app/services/employees.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css']
})
export class EmployeesListComponent {

  employees: Employee[] = [];

  constructor(private employeeService:EmployeesService,private router:Router){ }

  ngOnInit(): void{

    this.employeeService.getAllEmployees().subscribe({
      next:(res)=>{
      this.employees = res;
      },
      error:(err)=>{
          console.log(err)
      },
    })
  }

  deleteEmployee(id:string){
    this.employeeService.deleteEmployee(id).subscribe({
      next:(res)=>{
        const index = this.employees.findIndex(emp => emp.id);

        if (index !== -1){
          this.employees.splice(index,1)
        }
          alert("Employee deleted successfully");   
          
      },
      error:(err)=> {
        console.log(err);
      },
      
    })
  }
}
